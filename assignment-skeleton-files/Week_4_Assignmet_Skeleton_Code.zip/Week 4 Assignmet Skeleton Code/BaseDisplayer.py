class BaseDisplayer:
    def __init__(self):
        pass

    def display(self, grid):
        pass
